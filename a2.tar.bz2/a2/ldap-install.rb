#!/usr/bin/ruby
require 'fileutils'
require 'optparse'
# Input Option

#Install server and Client LDAP Packages
def installLdap()
	`yum install -y openldap-servers openldap-clients`
	puts("ldap server and client installed")
end
# Modify olcDatabase={2}hbd
def createModDb()
	oFile=File.new("db.ldif",'w')
	oFile.puts("dn: olcDatabase={2}hdb,cn=config")
	oFile.puts("changetype: modify")
	oFile.puts("replace: olcSuffix")
	oFile.puts("olcSuffix: dc=cit470,dc=nku,dc=edu")
	oFile.puts()
	oFile.puts("dn: olcDatabase={2}hdb,cn=config")
	oFile.puts("changetype: modify")
	oFile.puts("replace: olcRootDN")
	oFile.puts("olcRootDN: cn=Manager,dc=cit470,dc=nku,dc=edu")
	oFile.puts()
	oFile.puts("dn: olcDatabase={2}hdb,cn=config")
	oFile.puts("changetype: modify")
	oFile.puts("replace: olcRootPW")
 	oFile.puts("dn: olcDatabase={2}hdb,cn=config")
	 oFile.puts("changeType: modify")
	 oFile.puts("replace: olcAccess")	
	oFile.close()
end
# Modify olcDatabase={1},monitor
def createModMonitor()
	oFile=File.new("monitor.ldif", 'w')
	oFile.puts("dn: olcDatabase={1}monitor,cn=config")
	oFile.puts("changetype: modify")
	oFile.puts("replace: olcAccess")
	oFile.puts("olcAccess: {0}to * by dn.base=\"gidNumber=0+uidNumber=0,cn=peercred,cn=external, cn=auth\" read by dn.base=\"cn=Manager,dc=cit470,dc=nku,dc=edu\" read by * none")
oFile.close()
end
# Modify migrate_commons.ph file
def editMigrate_common()
	oFile=Dir.glob('/usr/share/migrationtools/migrate_common.ph')
	@oldBase='$DEFAULT_BASE = "dc=padl,dc=com";'
	@oldMail='$DEFAULT_MAIL_DOMAIN = "padl.com";'
	@newBase='$DEFAULT_BASE = "dc=cit470,dc=nku,dc=edu";'
	@newMail='$DEFAULT_MAIL_DOMAIN = "cit470.nku.edu";'
	oFile.each do |f|
		text = File.read(f)
		replace1 = text.gsub!(@oldBase, @newBase)
		replace2 = text.gsub!(@oldMail, @newMail)
		File.open(f, 'w') {|line| line.puts replace1 }
		File.open(f, 'w') {|line| line.puts replace2 }
	end
end
# Create base.ldif file
def createBaseLdap()
	oFile=File.new("base.ldif",'w')
	oFile.puts("dn: dc=cit470,dc=nku,dc=edu")
	oFile.puts("dc: cit470")
	oFile.puts("objectClass: top")
	oFile.puts("objectClass: domain")
	oFile.puts()
	oFile.puts("dn: ou=People,dc=cit470,dc=nku,dc=edu")
	oFile.puts("ou: People")
	oFile.puts("objectClass: top")
	oFile.puts("objectClass: organizationalUnit")
	oFile.puts()
	oFile.puts("dn: ou=Group,dc=cit470,dc=nku,dc=edu")
	oFile.puts("ou: Group")
	oFile.puts("objectClass: top")
	oFile.puts("objectClass: organizationalUnit")
	oFile.close()
end
# Add Database Schema
def addSchema()
	`ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/core.ldif`
	`ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/cosine.ldif`
	`ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/nis.ldif`
	`ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/inetorgperson.ldif`
end
# Start slapd service
def startSlapd()
	`systemctl start slapd`
	puts("Slapd is active")
end
# Stop slapd service
def stopSlapd()
	`systemctl stop slapd`
end
# Migrate /etc/passwd
def migratePasswd()
	`./migrate_passwd.pl /etc/passwd > passwd.ldif`
	`slapadd -v -l passwd.ldif`
end
# Migrate /etc/groups
def migrateGroupDb()
	`./migrate_group.pl /etc/group > group.ldif`
	`slapadd -v -l group.ldif`
end
# Change ldap dir ownership
# Change /var/lib/ldap file ownership
def chown()
`chown -R ldap:ldap /var/lib/ldap`
end
# Install and configure diradm
def diradm()
	# Change directory
	Dir.chdir('/usr/local')
	# Install diradm
	puts("Installing diradm...")
	`wget http://www.hits.at/diradm/diradm-1.3.tar.gz`
	`tar zxvf diradm-1.3.tar.gz`
	
	#Edit diradm.conf to use correct BINDIN,Userbase, and Groupbase names
        files = Dir.glob('./diradm-1.3/diradm.conf')
        @line1 = 'BINDDN="cn=Admin,o=System"'
        @line2 = 'USERBASE="ou=Users,ou=Accounts,o=System"'
        @line3 = 'GROUPBASE="ou=Groups,ou=Accounts,o=System"'
        @new1 = 'BINDDN="cn=Manager,dc=cit470,dc=nku,dc=edu"'
        @new2 = 'USERBASE="ou=People,dc=cit470,dc=nku,dc=edu"'
        @new3 = 'GROUPBASE="ou=Group,dc=cit470,dc=nku,dc=edu"'


        files.each do |file_name|
                text = File.read(file_name)
                replace1 = text.gsub!(@line1, @new1)
                replace2 = text.gsub!(@line2, @new2)
                replace3 = text.gsub!(@line3, @new3)
                File.open(file_name, "w") { |file| file.puts replace1 }
                File.open(file_name, "w") { |file| file.puts replace2 }
                File.open(file_name, "w") { |file| file.puts replace3 }
	end
	# copy diradm.conf to /etc/
	`cp /usr/local/diradm-1.3/diradm.conf /etc/`
end
# Set ldap root password and allow client user to change their password
def authuser()
	file = Dir.glob('/etc/openldap/slapd.d/cn\=config/olcDatabase\=\{2\}hdb.ldif')
	file.each do |f|

	File.open(f,"a") { |f| f.puts "olcRootPW: {SSHA}UAeB7wKojZaS5M2x1fJk2m/ncm4gp/B7" }
		File.open(f,"a") { |f| f.puts "olcAccess: {0}to attrs=userPassword,shadowLastChange by dn=\"cn=Manager,dc=cit470,dc=nku,dc=edu\" write by anonymous auth by self write by \* none" }
	File.open(f,"a") { |f| f.puts "olcAccess: {1}to dn.base=\"\" by \* read" }
	File.open(f,"a") { |f| f.puts "olcAccess: {2}to \* by dn=\"cn=Manager,dc=cit470,dc=nku,dc=edu\" write by \* read" } 
	end
end
# Help option
if ARGV[0] == "-h" || ARGV[0] == "--help"
		puts "Usage: ./install-ldap-server.rb ipaddess/mask ex:./install-ldap-server.rb 10.0.1.0/24"
# Main code
#If no argument is passed.
elsif (ARGV[0] == nil)
	installLdap()	# Install ldap server and client
	startSlapd()	# Start slapd service
	`systemctl enable slapd`	# Enable slapd to start automatically
	puts("Configuring Ldap...")
	createModDb()	# Modify the ldap configuration file
	createModMonitor() # Modify the monitor.ldif
	Dir.chdir ('/etc/openldap/slapd.d/cn=config/')
	`ldapmodify -Y EXTERNAL  -H ldapi:/// -f ~/db.ldif`
	puts("olcDatabase={2}hbd.ldif has been modified")
	`ldapmodify -Y EXTERNAL  -H ldapi:/// -f ~/monitor.ldif`
	puts("olcDatabase={1}monitor has been modified")
	puts("Ldap configuration done!")
	# this is to input the security rule to the iptables "firewall".
	puts("Modifying firewall rules")
	# Set firewall rules
	`firewall-cmd --zone=public --add-port=389/tcp --permanent`
	`firewall-cmd --zone=public --add-port=638/tcp --permanent`  
	puts("Reloading firewall...")
	`firewall-cmd --reload`
	puts("Firewall configuration done!")
	Dir.chdir('/var/lib/ldap/')
	`rm *`
	`cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG`
	chown()
	puts("Installing nss_ldap")
	`yum install nss_ldap -y`
	puts("nss_ldap installed successfully!")
	puts("Installing migrationtoos")
	`yum install migrationtools -y`
	puts("migrationtools installed successfully")
	Dir.chdir('/usr/share/migrationtools')
	`cp migrate_common.ph migrate_common.ph.BAK`
	editMigrate_common()
	createBaseLdap()
	addSchema()
	stopSlapd()
	puts("slapd stoped")
	chown()
	`slapadd -v -l base.ldif`
	migratePasswd()
	migrateGroupDb()
	chown()
	startSlapd()
	# Install diradm
	diradm()
	authuser()
	Dir.chdir('/usr/local/diradm-1.3')
	`./diradm useradd -c \"Team 4 Test Account\" -s /bin/bash -m -p \"password\" team4`
end
